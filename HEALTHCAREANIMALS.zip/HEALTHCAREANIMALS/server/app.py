from flask import Flask
from flask import request
import pymysql
import json
import pandas as pd
import cv2
import numpy as np
import threading
from werkzeug.utils import secure_filename
import os



app = Flask(__name__)

UPLOAD_FOLDER = 'static/uploadedimg/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = set(['jpeg', 'jpg', 'png', 'gif'])
app.secret_key = 'any random string'


# print("[info] Model loading....")
# test_model = load_model("birdClassify.hp5")
# image_size=224
print("model loaded successfully!!")

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="speciesclass", charset='utf8' )
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()



@app.route('/userRegister', methods=['GET', 'POST'])
def userRegister():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password")        
        email = request.form.get("emailid")
        mobile = request.form.get("mobilenumber")        
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM register WHERE username = %s', (username))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:        
            sql1 = "INSERT INTO register(username, email,mobile, password) VALUES (%s, %s, %s, %s);"
            val1 = (username, email, mobile, passw)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"  
    
@app.route('/userLogin', methods=['GET', 'POST'])
def userLogin():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password")       
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username, passw))
        count = cursor.rowcount
        if count > 0:
            return "success"
        else:
            return "Fail"





@app.route('/birds', methods=['GET', 'POST'])
def birds():
    print("hii")
    if request.method == 'POST': 
        print("hiinnnn")
        cursor.execute('SELECT * FROM infobird')
        row = cursor.fetchall()
        jsonObj = json.dumps(row)
        print(jsonObj)
        return jsonObj 
    
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':  
        Username = request.form.get("Username")
        cursor.execute('SELECT * FROM register where username= %s;',(Username))
        row = cursor.fetchall()
        jsonObj = json.dumps(row)
        # print(jsonObj)
        return jsonObj 
   
if __name__ == "__main__":
    app.run("0.0.0.0")
