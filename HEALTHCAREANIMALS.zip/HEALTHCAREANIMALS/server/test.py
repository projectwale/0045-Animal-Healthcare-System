from flask import Flask
from flask import request
import pymysql
import json
import pandas as pd
import cv2
import numpy as np
import threading
from werkzeug.utils import secure_filename
import os

import numpy as np
import tensorflow
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import load_model
import warnings
warnings.filterwarnings("ignore")
import pickle



app = Flask(__name__)

UPLOAD_FOLDER = 'static/uploadedimg/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = set(['jpeg', 'jpg', 'png', 'gif'])
app.secret_key = 'any random string'


print("[info] Model loading....")
test_model = load_model("birdClassify.hp5")
image_size=224
print("model loaded successfully!!")

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="speciesclass", charset='utf8' )
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()



@app.route('/userRegister', methods=['GET', 'POST'])
def userRegister():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password")        
        email = request.form.get("emailid")
        mobile = request.form.get("mobilenumber")        
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM register WHERE username = %s', (username))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:        
            sql1 = "INSERT INTO register(username, email,mobile, password) VALUES (%s, %s, %s, %s);"
            val1 = (username, email, mobile, passw)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"  
    
@app.route('/userLogin', methods=['GET', 'POST'])
def userLogin():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password")       
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username, passw))
        count = cursor.rowcount
        if count > 0:
            return "success"
        else:
            return "Fail"


@app.route('/uploadfile',methods=['POST','GET'])
def uploadfile():
    if request.method == "POST":
        f2= request.files['bill']
        filename_secure = secure_filename(f2.filename)
        split_filename = filename_secure.split('_')[-1]
        f2.save(os.path.join(app.config['UPLOAD_FOLDER'], split_filename))        
        return "success"
    return "fail"
    
@app.route('/getResult', methods=['GET', 'POST'])
def getResult():
    if request.method == 'POST':    
        # try:    
        filename = request.form.get("imagename") 
        
        print(filename)
        
        img_path = "static/uploadedimg/"+filename
        BIRDS = ['ABBOTTS BOOBY',
                'ABYSSINIAN GROUND HORNBILL',
                'AFRICAN PIED HORNBILL',
                'AFRICAN PYGMY GOOSE',
                'ALEXANDRINE PARAKEET',
                'AMERICAN AVOCET',
                'AMERICAN BITTERN',
                'AMERICAN FLAMINGO',
                'AMERICAN PIPIT',
                'AMERICAN WIGEON',
                'ASHY STORM PETREL',
                'ASIAN GREEN BEE EATER',
                'AUCKLAND SHAQ',
                'AUSTRALASIAN FIGBIRD',
                'AZARAS SPINETAIL',
                'BALD EAGLE',
                'BANDED BROADBILL',
                'BAR-TAILED GODWIT',
                'CHIPPING SPARROW',
                'CROW',
                'INDIAN PITTA',
                'KING EIDER',
                'RUFOUS KINGFISHER',
                'SNOWY OWL',
                'STEAMER DUCK']
        
        img = image.load_img(img_path,target_size=(image_size, image_size))
        x = image.img_to_array(img)
        img_4d=x.reshape(1,224,224,3)
        
        prediction = test_model.predict(img_4d)
        new_pred=np.argmax(prediction[0])
        predicted_name = BIRDS[new_pred]
        print("Predicted Image Name: "+str(BIRDS[new_pred]))
        print("---------------------------------------------------------")
        
        return str(BIRDS[new_pred])
    
        cursor.execute('SELECT * FROM infobird where NAME= %s;',(str(predicted_name)))
        row = cursor.fetchone()
        # print(row)
        jsonObj = json.dumps([row,str(predicted_name)+""+"Detected in Image"])
        
        print("jsonObj")
        print(jsonObj)
        
        return jsonObj

       
    return "unknow"

@app.route('/birds', methods=['GET', 'POST'])
def birds():
    print("hii")
    if request.method == 'POST': 
        print("hiinnnn")
        cursor.execute('SELECT * FROM infobird')
        row = cursor.fetchall()
        jsonObj = json.dumps(row)
        print(jsonObj)
        return jsonObj 
    
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':  
        Username = request.form.get("Username")
        cursor.execute('SELECT * FROM register where username= %s;',(Username))
        row = cursor.fetchall()
        jsonObj = json.dumps(row)
        # print(jsonObj)
        return jsonObj 
   
if __name__ == "__main__":
    app.run("0.0.0.0")
