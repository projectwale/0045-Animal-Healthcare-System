package com.example.myapplication;

import android.graphics.Bitmap;

public class ExampleItem6 {

    private Bitmap mImageResource;
    private String mText1;
    private String mText2;
    private String mText3;
    private String mText4;
    private String mText5;
    private String mText6;
    private String mText7;
    private String mText8;

    private String mText10;


    public ExampleItem6(String mText1, String mText2, String mText3, String mText4, String mText5, String mText6, String mText7, String mText8,  Bitmap imageResource, String mText10) {
        this.mText1 = mText1;
        this.mText2 = mText2;
        this.mText3 = mText3;
        this.mText4 = mText4;
        this.mText5 = mText5;
        this.mText6 = mText6;
        this.mText7 = mText7;
        this.mText8 = mText8;
        this.mImageResource = imageResource;
        this.mText10 = mText10;

    }

    public String getmText1() {
        return mText1;
    }

    public void setmText1(String mText1) {
        this.mText1 = mText1;
    }

    public String getmText2() {
        return mText2;
    }

    public void setmText2(String mText2) {
        this.mText2 = mText2;
    }

    public String getmText3() {
        return mText3;
    }

    public void setmText3(String mText3) {
        this.mText3 = mText3;
    }

    public String getmText4() {
        return mText4;
    }

    public void setmText4(String mText4) {
        this.mText4 = mText4;
    }

    public String getmText5() {
        return mText5;
    }

    public void setmText5(String mText5) {
        this.mText5 = mText5;
    }




    public String getmText6() {
        return mText6;
    }

    public void setmText6(String mText6) {
        this.mText6 = mText6;
    }

    public String getmText7() {
        return mText7;
    }

    public void setmText7(String mText7) {
        this.mText7 = mText7;
    }

    public String getmText8() {
        return mText8;
    }

    public void setmText8(String mText8) {this.mText8 = mText8;}

    public Bitmap getmText9() {return mImageResource;}

    public void setmImageResource(Bitmap mImageResource) {
        this.mImageResource = mImageResource;
    }

    public String getmText10() {
        return mText10;
    }

    public void setmText10(String mText10) {
        this.mText10 = mText10;
    }



}