package com.example.myapplication;

public class UrlLinks {
    public static String urlserver="";

    public static String urlserverpython="http://192.168.0.103:5000/";

    public static String registrationurl=urlserver+"registerUser";
    public static String pyregister=urlserverpython+"userRegister";
    public static String pylogin=urlserverpython+"userLogin";

    public static String uploadfile=urlserverpython+"uploadfile";
    public static String getResult=urlserverpython+"getResult";

    public static String getALLbirds=urlserverpython+"birds";

    public static String profile=urlserverpython+"profile";
}
